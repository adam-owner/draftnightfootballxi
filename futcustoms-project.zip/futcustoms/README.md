# FUTCUSTOMS: setup, deployment and testing

## 1. Database (Supabase)
1. Open your project, then SQL Editor. Run these files in order: `supabase/migrations/001_schema.sql`, `002_functions.sql`, `003_seed.sql`.
2. Authentication > Providers: Google is enabled. In Google Cloud Console the OAuth client must allow this redirect URI:
   `https://aosjthgeithkjazpzaze.supabase.co/auth/v1/callback`
3. Authentication > URL Configuration: set Site URL to your Vercel URL and add `https://YOUR-APP.vercel.app/**` (and `http://localhost:3000/**` for local tests) to Redirect URLs.

## 2. Deploy on Vercel
Environment variables to add (Project > Settings > Environment Variables):

| Name | Value |
|---|---|
| `SUPABASE_URL` | `https://aosjthgeithkjazpzaze.supabase.co` |
| `SUPABASE_PUBLISHABLE_KEY` | your `sb_publishable_...` key |

Both are public by design. Never add the service_role key. Deploy with the CLI (`npm i -g vercel`, then `vercel login`, then `vercel --prod` in this folder) or import the repo from GitHub. Vercel Drop is static-only and will not run `api/config.js`, so use the CLI or GitHub.
`public/index.html` is the game. `api/config.js` hands the two variables to the browser at runtime. Without them the game still works in guest mode.

## 3. Test Google sign-in
1. Open your deployed site, go to Account, press Continue with Google, sign in with `adamsamyhal@gmail.com`.
2. You return to the site signed in. The nav shows Account and Admin (owner only).
3. Supabase > Table Editor > `profiles`: a row exists with your user id, a `Manager123abc` username and the starting coins. Authentication > Users shows the same id.
4. Refresh the page: you stay signed in (the session is stored and refreshed automatically). Sign out and back in: coins and cards are the same.
5. Sign in with a second Google account: it gets its own profile, no Admin tab, and cannot see your data.

## 4. Verify security (browser console on the deployed site)
- `await sb.from('profiles').update({coins:999999}).eq('id',ME.id)` must fail or change nothing.
- `await sb.rpc('admin_adjust_coins',{p_user:ME.id,p_mode:'give',p_amount:5,p_reason:'x'})` as a normal player must say `permission denied`.
- `(await sb.from('profiles').select('*')).data.length` must be 1 for a normal player.

## 5. Owner dashboard
Admin tabs: Coins (give, remove, set, bulk, unlimited for yourself), Rewards (coins, cards, packs and any item type, quantity, permanent or expiring), Users & inventory (name, avatar, XP, level, remove items), Players (edit rating, rarity, availability, create and delete custom players), Packs & shop (prices, pool, rating range, on sale, new packs), Economy & XP (every reward amount, `xp_per_level`, daily caps; 0 disables a reward), Transactions (history and reversal), Permissions (owner only), News (post announcements).
Only `adamsamyhal@gmail.com` (confirmed Google account) is owner. Administrators have nothing until you tick individual permissions. Every coin or item change writes a transaction with user, amount, balances, administrator, time and reason. Destructive actions ask for confirmation.

## 6. Honest limits
- The match simulator runs in the browser, so match and quest results are reported by the client. The server limits damage (one claim per reward per period, one match reward per 90 seconds, a daily cap, amounts you control) but cannot prove a match was really played. True server-side simulation needs a Supabase Edge Function.
- Kits, badges, stadiums and club items can be granted and stored, but the game has no screens that use them yet. There are no per-player prices; the Shop Manager edits pack prices.
- The SQL has not been executed by me (no database here). Run it on a test project first.

## 7. What was tested
Client code (sign-in call, session loading, owner detection, all 9 dashboard tabs and every admin action, starter squad, pack purchase, sign-out) was run against a mock Supabase client and sent the correct function calls. It was not run against the live database, and a real Google sign-in needs a person at a browser.

## 8. If Google sign-in fails
Open Account, press Test connection, and read the result. The usual causes:
1. You opened the claude.ai preview. Google refuses to sign in inside a frame. Use your own Vercel address.
2. Supabase > Authentication > URL Configuration does not list your site. Add `https://YOUR-APP.vercel.app/**` and set it as Site URL.
3. Google Cloud OAuth client is missing the redirect URI `https://aosjthgeithkjazpzaze.supabase.co/auth/v1/callback`.
4. The SQL migrations were not run ("relation does not exist" in the test).
The app now uses your project URL and publishable key as built-in defaults (both are public by design), so it connects even if the Vercel variables are missing. Variables set in Vercel override them.

## 9. Deploy commands
```
npm i -g vercel
vercel login
vercel --prod
```
Run them inside this folder. Then add the two variables in the Vercel dashboard if you want to override the defaults.
