-- FUTCUSTOMS 001: tables + Row Level Security. Run in the Supabase SQL editor, in order 001, 002, 003.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique check (username ~ '^[A-Za-z0-9_]{3,16}$'),
  avatar text not null default '⚽' check (char_length(avatar) <= 8),
  coins bigint not null default 0 check (coins >= 0),
  xp bigint not null default 0 check (xp >= 0),
  level int not null default 1 check (level >= 1),
  stats jsonb not null default '{}',
  starter_claimed boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.admin_permissions (
  user_id uuid not null references auth.users(id) on delete cascade,
  permission text not null,
  granted_by uuid,
  granted_at timestamptz not null default now(),
  primary key (user_id, permission)
);
create table public.inventory (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  item_type text not null check (item_type ~ '^[a-z_]{2,24}$'),
  item_key text not null,
  qty int not null default 1 check (qty > 0),
  meta jsonb not null default '{}',
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.inventory (user_id);
create table public.transactions (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  actor_id uuid,
  kind text not null,
  item text,
  delta bigint not null default 0,
  prev_balance bigint,
  new_balance bigint,
  reason text,
  reversed_of bigint references public.transactions(id),
  created_at timestamptz not null default now()
);
create index on public.transactions (user_id, created_at desc);
create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid, action text not null, detail jsonb not null default '{}', created_at timestamptz not null default now()
);
create table public.reward_claims (
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null, key text not null, period text not null, claimed_at timestamptz not null default now(),
  primary key (user_id, kind, key, period)
);
create table public.settings (key text primary key check (key ~ '^[a-z0-9_.]{2,60}$'), value jsonb not null, updated_by uuid, updated_at timestamptz not null default now());
create table public.packs (
  id text primary key check (id ~ '^[a-z0-9_]{1,24}$'), name text not null, price int not null check (price >= 0),
  cards int not null default 3 check (cards between 1 and 20),
  pool_min int not null, pool_max int not null, er_min int not null, er_max int not null,
  color text default '#8a949e', descr text default '', active boolean not null default true, sort int not null default 0
);
create table public.players (
  key text primary key, name text not null, pos text not null check (pos in ('GK','CB','LB','RB','CDM','CM','CAM','LW','RW','ST')),
  rating int not null check (rating between 40 and 99), club_code text, team text, club text, rarity text check (rarity in ('Common','Epic','Rare','Legendary')),
  meta jsonb not null default '{}', active boolean not null default true, custom boolean not null default false
);
create table public.announcements (
  id bigint generated always as identity primary key, title text not null, body text not null,
  kind text not null default 'update', pinned boolean not null default false, author uuid, created_at timestamptz not null default now()
);

-- helper functions needed by policies
create function public.is_owner() returns boolean language sql stable security definer set search_path = public, auth as $$
  select exists (select 1 from auth.users u where u.id = auth.uid() and lower(u.email) = 'adamsamyhal@gmail.com'
    and u.email_confirmed_at is not null and (u.raw_app_meta_data->'providers') ? 'google') $$;
create function public.has_perm(p text) returns boolean language sql stable security definer set search_path = public as $$
  select public.is_owner() or exists (select 1 from public.admin_permissions a where a.user_id = auth.uid() and a.permission = p) $$;

alter table public.profiles enable row level security;
alter table public.admin_permissions enable row level security;
alter table public.inventory enable row level security;
alter table public.transactions enable row level security;
alter table public.audit_log enable row level security;
alter table public.reward_claims enable row level security;
alter table public.settings enable row level security;
alter table public.packs enable row level security;
alter table public.players enable row level security;
alter table public.announcements enable row level security;

-- Read policies only. There are NO insert/update/delete policies: every write goes through the checked functions in 002.
create policy profiles_read on public.profiles for select to authenticated using (id = auth.uid() or public.has_perm('view_balances'));
create policy inventory_read on public.inventory for select to authenticated using (user_id = auth.uid() or public.has_perm('edit_inventory') or public.has_perm('view_balances'));
create policy tx_read on public.transactions for select to authenticated using (user_id = auth.uid() or public.has_perm('view_transactions'));
create policy audit_read on public.audit_log for select to authenticated using (public.has_perm('view_transactions'));
create policy perms_read on public.admin_permissions for select to authenticated using (user_id = auth.uid() or public.is_owner());
create policy claims_read on public.reward_claims for select to authenticated using (user_id = auth.uid());
create policy settings_read on public.settings for select to anon, authenticated using (true);
create policy packs_read on public.packs for select to anon, authenticated using (true);
create policy players_read on public.players for select to anon, authenticated using (true);
create policy news_read on public.announcements for select to anon, authenticated using (true);

-- belt and braces: browsers can never write these tables directly
revoke insert, update, delete, truncate on all tables in schema public from anon, authenticated;
