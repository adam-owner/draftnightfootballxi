-- FUTCUSTOMS 002: server-side functions. All money/inventory/role changes happen here, in one transaction each.
create function public._s(k text, d numeric) returns numeric language sql stable security definer set search_path = public as
$$ select coalesce((select (value #>> '{}')::numeric from public.settings where key = k), d) $$;
create function public._audit(a text, d jsonb) returns void language sql security definer set search_path = public as
$$ insert into public.audit_log(actor_id, action, detail) values (auth.uid(), a, d) $$;
create function public._need(p text) returns void language plpgsql security definer set search_path = public as $$
begin if auth.uid() is null or not public.has_perm(p) then raise exception 'permission denied: %', p; end if; end $$;
create function public._guard(target uuid) returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if target = auth.uid() and not public.is_owner() then raise exception 'you cannot edit your own account'; end if;
  if exists (select 1 from auth.users u where u.id = target and lower(u.email) = 'adamsamyhal@gmail.com') and not public.is_owner() then
    raise exception 'only the owner can change the owner account'; end if;
end $$;
create function public._apply(p_user uuid, p_delta bigint, p_kind text, p_item text, p_reason text, p_actor uuid) returns bigint
language plpgsql security definer set search_path = public as $$
declare prev bigint; nw bigint;
begin
  select coins into prev from public.profiles where id = p_user for update;
  if not found then raise exception 'user not found'; end if;
  nw := prev + p_delta;
  if nw < 0 then raise exception 'insufficient coins'; end if;
  update public.profiles set coins = nw where id = p_user;
  insert into public.transactions(user_id, actor_id, kind, item, delta, prev_balance, new_balance, reason)
    values (p_user, p_actor, p_kind, p_item, p_delta, prev, nw, p_reason);
  return nw;
end $$;
create function public._roll(p_user uuid, p_pack text, p_src text) returns jsonb language plpgsql security definer set search_path = public as $$
declare pk public.packs; r record; er int; iid uuid; res jsonb := '[]'; n int := 0;
begin
  select * into pk from public.packs where id = p_pack;
  for r in select key, rating from public.players where active and rating between pk.pool_min and pk.pool_max order by random() limit pk.cards loop
    er := least(r.rating, pk.er_min + floor(random() * (pk.er_max - pk.er_min + 1))::int);
    insert into public.inventory(user_id, item_type, item_key, meta) values (p_user, 'card', r.key, jsonb_build_object('er', er, 'pack', p_pack, 'src', p_src)) returning id into iid;
    res := res || jsonb_build_object('id', iid, 'key', r.key, 'er', er); n := n + 1;
  end loop;
  if n = 0 then raise exception 'no players available for this pack'; end if;
  return res;
end $$;

-- new users get a profile automatically
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, username, coins) values (new.id, 'Manager' || substr(replace(new.id::text, '-', ''), 1, 6), public._s('starting_coins', 0)::bigint) on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ---------- player-facing functions ----------
create function public.ensure_profile() returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  insert into public.profiles(id, username, coins) values (auth.uid(), 'Manager' || substr(replace(auth.uid()::text, '-', ''), 1, 6), public._s('starting_coins', 0)::bigint) on conflict do nothing;
end $$;
create function public.am_owner() returns boolean language sql stable security definer set search_path = public as $$ select public.is_owner() $$;
create function public.update_my_profile(p_username text, p_avatar text) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if p_username !~ '^[A-Za-z0-9_]{3,16}$' then raise exception 'username must be 3-16 letters, numbers or underscores'; end if;
  if char_length(p_avatar) > 8 then raise exception 'bad avatar'; end if;
  update public.profiles set username = p_username, avatar = p_avatar where id = auth.uid();
end $$;
create function public.claim_starter() returns jsonb language plpgsql security definer set search_path = public as $$
declare slots text[] := array['GK','CB','CB','LB','RB','CM','CM','CDM','LW','RW','ST']; s text; r record; er int; res jsonb := '[]'; iid uuid;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  perform 1 from public.profiles where id = auth.uid() for update;
  if (select starter_claimed from public.profiles where id = auth.uid()) then raise exception 'starter squad already claimed'; end if;
  foreach s in array slots loop
    select key, rating into r from public.players p where p.active and p.pos = s and p.rating <= 84
      and not exists (select 1 from public.inventory i where i.user_id = auth.uid() and i.item_key = p.key) order by random() limit 1;
    if r.key is null then raise exception 'not enough players for starter squad'; end if;
    er := least(r.rating, 66 + floor(random() * 10)::int);
    insert into public.inventory(user_id, item_type, item_key, meta) values (auth.uid(), 'card', r.key, jsonb_build_object('er', er, 'src', 'starter')) returning id into iid;
    res := res || jsonb_build_object('id', iid, 'key', r.key, 'er', er);
  end loop;
  update public.profiles set starter_claimed = true where id = auth.uid();
  insert into public.transactions(user_id, kind, item, reason) values (auth.uid(), 'starter', '11 cards', 'starter squad');
  return res;
end $$;
create function public.buy_pack(p_pack text) returns jsonb language plpgsql security definer set search_path = public as $$
declare pk public.packs;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  select * into pk from public.packs where id = p_pack and active;
  if not found then raise exception 'pack not available'; end if;
  perform public._apply(auth.uid(), -pk.price::bigint, 'buy_pack', pk.id, 'pack purchase', null);
  return public._roll(auth.uid(), pk.id, 'shop');
end $$;
create function public.open_pack_item(p_inv uuid) returns jsonb language plpgsql security definer set search_path = public as $$
declare it public.inventory; res jsonb;
begin
  select * into it from public.inventory where id = p_inv and user_id = auth.uid() and item_type = 'pack' for update;
  if not found then raise exception 'pack not found'; end if;
  if it.expires_at is not null and it.expires_at < now() then raise exception 'this pack has expired'; end if;
  if it.qty > 1 then update public.inventory set qty = qty - 1 where id = it.id; else delete from public.inventory where id = it.id; end if;
  res := public._roll(auth.uid(), it.item_key, 'inventory');
  insert into public.transactions(user_id, kind, item, reason) values (auth.uid(), 'open_pack', it.item_key, 'opened from inventory');
  return res;
end $$;
-- NOTE: quest progress is tracked in the browser (the match simulator runs client-side), so these claims are
-- capped by one claim per reward per period and by the amounts you set in Economy Settings.
create function public.claim_reward(p_kind text, p_key text) returns bigint language plpgsql security definer set search_path = public as $$
declare per text; amt numeric := 0; n int; bal bigint;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if p_key !~ '^[a-z0-9_]{1,24}$' then raise exception 'bad key'; end if;
  if p_kind = 'quest' then per := to_char(now() at time zone 'utc', 'IYYY-IW'); amt := public._s('reward.quest.' || p_key, 0);
  elsif p_kind = 'milestone' then per := 'once'; amt := public._s('reward.milestone.' || p_key, 0);
  elsif p_kind = 'daily' then per := to_char(now() at time zone 'utc', 'YYYY-MM-DD'); amt := public._s('reward.daily.login', 0);
  elsif p_kind = 'daily_pack' then per := to_char(now() at time zone 'utc', 'YYYY-MM-DD');
  else raise exception 'unknown reward'; end if;
  if p_kind <> 'daily_pack' and amt <= 0 then raise exception 'this reward is disabled'; end if;
  perform 1 from public.profiles where id = auth.uid() for update;
  insert into public.reward_claims(user_id, kind, key, period) values (auth.uid(), p_kind, p_key, per) on conflict do nothing;
  get diagnostics n = row_count;
  if n = 0 then raise exception 'already claimed'; end if;
  if p_kind = 'daily_pack' then
    if not exists (select 1 from public.packs where id = 'b' and active) then raise exception 'daily pack unavailable'; end if;
    insert into public.inventory(user_id, item_type, item_key, meta) values (auth.uid(), 'pack', 'b', '{"src":"daily"}');
    insert into public.transactions(user_id, kind, item, reason) values (auth.uid(), 'reward_daily_pack', 'b', 'daily free pack');
    select coins into bal from public.profiles where id = auth.uid(); return bal;
  end if;
  return public._apply(auth.uid(), amt::bigint, 'reward_' || p_kind, p_kind || ':' || p_key, 'reward claim', null);
end $$;
create function public.report_match(p_result text, p_goals int, p_career boolean) returns jsonb language plpgsql security definer set search_path = public as $$
declare pre text; coins bigint; xpg bigint; lv int; last_t timestamptz; cnt int;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if p_result not in ('W','D','L') or p_goals < 0 or p_goals > 15 then raise exception 'bad match report'; end if;
  perform 1 from public.profiles where id = auth.uid() for update;
  select max(created_at), count(*) filter (where created_at > date_trunc('day', now())) into last_t, cnt from public.transactions where user_id = auth.uid() and kind = 'match_reward';
  if last_t is not null and now() - last_t < interval '90 seconds' then raise exception 'match reward too soon after the last one'; end if;
  if cnt >= public._s('max_match_rewards_per_day', 30) then raise exception 'daily match reward limit reached'; end if;
  pre := case when p_career then 'reward.match.' else 'reward.quick.' end;
  coins := (public._s(pre || case p_result when 'W' then 'win' when 'D' then 'draw' else 'loss' end, 0) + p_goals * public._s(pre || 'goal', 0))::bigint;
  xpg := public._s('xp.' || case p_result when 'W' then 'win' when 'D' then 'draw' else 'loss' end, 0)::bigint;
  perform public._apply(auth.uid(), coins, 'match_reward', p_result || ' ' || p_goals, case when p_career then 'career match' else 'quick match' end, null);
  update public.profiles set xp = xp + xpg, level = 1 + ((xp + xpg) / greatest(1, public._s('xp_per_level', 200)))::int where id = auth.uid() returning level into lv;
  return jsonb_build_object('coins', coins, 'xp', xpg, 'level', lv);
end $$;

-- ---------- admin functions (every one checks its own permission) ----------
create function public.admin_list_users(p_q text) returns table (id uuid, username text, email text, coins bigint, xp bigint, level int, created_at timestamptz)
language plpgsql security definer set search_path = public, auth as $$
begin
  perform public._need('view_balances');
  return query select p.id, p.username, u.email::text, p.coins, p.xp, p.level, p.created_at from public.profiles p join auth.users u on u.id = p.id
    where coalesce(p_q, '') = '' or p.username ilike '%' || p_q || '%' or u.email ilike '%' || p_q || '%' or p.id::text = p_q order by p.created_at desc limit 100;
end $$;
create function public.admin_get_user(p_user uuid) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public._need('view_balances');
  return jsonb_build_object('profile', (select to_jsonb(p) from public.profiles p where p.id = p_user),
    'inventory', coalesce((select jsonb_agg(to_jsonb(i) order by i.created_at desc) from public.inventory i where i.user_id = p_user), '[]'));
end $$;
create function public.admin_adjust_coins(p_user uuid, p_mode text, p_amount bigint, p_reason text) returns bigint language plpgsql security definer set search_path = public as $$
declare cur bigint;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'a reason is required'; end if;
  if p_amount < 0 or p_amount > 1000000000000 then raise exception 'bad amount'; end if;
  perform public._need(case p_mode when 'give' then 'give_coins' when 'remove' then 'remove_coins' when 'set' then 'set_coins' else 'invalid' end);
  perform public._guard(p_user);
  select coins into cur from public.profiles where id = p_user for update;
  if not found then raise exception 'user not found'; end if;
  return public._apply(p_user, case p_mode when 'give' then p_amount when 'remove' then -p_amount else p_amount - cur end, 'admin_' || p_mode, 'coins', p_reason, auth.uid());
end $$;
create function public.admin_bulk_give(p_users uuid[], p_amount bigint, p_reason text) returns int language plpgsql security definer set search_path = public as $$
declare u uuid; n int := 0;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'a reason is required'; end if;
  if p_amount <= 0 or p_amount > 1000000000 or coalesce(array_length(p_users, 1), 0) > 500 then raise exception 'bad amount or too many users'; end if;
  perform public._need('bulk_give');
  foreach u in array p_users loop perform public._guard(u); perform public._apply(u, p_amount, 'admin_bulk_give', 'coins', p_reason, auth.uid()); n := n + 1; end loop;
  return n;
end $$;
create function public.admin_reverse_tx(p_tx bigint, p_reason text) returns bigint language plpgsql security definer set search_path = public as $$
declare t public.transactions; bal bigint;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'a reason is required'; end if;
  perform public._need('reverse_transactions');
  select * into t from public.transactions where id = p_tx for update;
  if not found then raise exception 'transaction not found'; end if;
  if t.reversed_of is not null then raise exception 'a reversal cannot be reversed'; end if;
  if exists (select 1 from public.transactions where reversed_of = p_tx) then raise exception 'already reversed'; end if;
  if t.delta = 0 then raise exception 'nothing to reverse: remove granted items in the inventory editor'; end if;
  perform public._guard(t.user_id);
  bal := public._apply(t.user_id, -t.delta, 'reversal', 'tx #' || p_tx, p_reason, auth.uid());
  update public.transactions set reversed_of = p_tx where id = (select max(id) from public.transactions where user_id = t.user_id);
  return bal;
end $$;
create function public.admin_grant_item(p_user uuid, p_type text, p_key text, p_qty int, p_days int, p_meta jsonb, p_reason text) returns void language plpgsql security definer set search_path = public as $$
declare i int; bal bigint; er int;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'a reason is required'; end if;
  if p_type !~ '^[a-z_]{2,24}$' or p_qty < 1 or p_qty > 1000 or p_days < 0 or p_days > 3650 then raise exception 'bad item request'; end if;
  perform public._need(case p_type when 'card' then 'give_cards' when 'pack' then 'give_packs' else 'give_items' end);
  perform public._guard(p_user);
  if p_type = 'card' then
    if not exists (select 1 from public.players where key = p_key) then raise exception 'unknown player key'; end if;
    er := coalesce((p_meta->>'er')::int, (select rating from public.players where key = p_key));
    for i in 1..p_qty loop insert into public.inventory(user_id, item_type, item_key, meta, expires_at) values (p_user, 'card', p_key, jsonb_build_object('er', er, 'src', 'admin'), case when p_days > 0 then now() + make_interval(days => p_days) end); end loop;
  else
    if p_type = 'pack' and not exists (select 1 from public.packs where id = p_key) then raise exception 'unknown pack id'; end if;
    insert into public.inventory(user_id, item_type, item_key, qty, meta, expires_at) values (p_user, p_type, left(p_key, 80), p_qty, coalesce(p_meta, '{}') || '{"src":"admin"}', case when p_days > 0 then now() + make_interval(days => p_days) end);
  end if;
  select coins into bal from public.profiles where id = p_user;
  insert into public.transactions(user_id, actor_id, kind, item, delta, prev_balance, new_balance, reason) values (p_user, auth.uid(), 'admin_grant', p_type || ':' || p_key || ' x' || p_qty, 0, bal, bal, p_reason);
end $$;
create function public.admin_remove_item(p_inv uuid, p_reason text) returns void language plpgsql security definer set search_path = public as $$
declare it public.inventory; bal bigint;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'a reason is required'; end if;
  perform public._need('edit_inventory');
  select * into it from public.inventory where id = p_inv for update;
  if not found then raise exception 'item not found'; end if;
  perform public._guard(it.user_id);
  delete from public.inventory where id = p_inv;
  select coins into bal from public.profiles where id = it.user_id;
  insert into public.transactions(user_id, actor_id, kind, item, delta, prev_balance, new_balance, reason) values (it.user_id, auth.uid(), 'admin_remove_item', it.item_type || ':' || it.item_key, 0, bal, bal, p_reason);
end $$;
create function public.admin_update_user(p_user uuid, p_username text, p_avatar text, p_xp bigint, p_level int, p_reason text) returns void language plpgsql security definer set search_path = public as $$
declare o public.profiles; bal bigint;
begin
  if coalesce(trim(p_reason), '') = '' then raise exception 'a reason is required'; end if;
  perform public._need('edit_users'); perform public._guard(p_user);
  if p_username !~ '^[A-Za-z0-9_]{3,16}$' or p_xp < 0 or p_level < 1 or char_length(p_avatar) > 8 then raise exception 'bad values'; end if;
  select * into o from public.profiles where id = p_user for update;
  if not found then raise exception 'user not found'; end if;
  update public.profiles set username = p_username, avatar = p_avatar, xp = p_xp, level = p_level where id = p_user;
  insert into public.transactions(user_id, actor_id, kind, item, delta, prev_balance, new_balance, reason)
    values (p_user, auth.uid(), 'admin_edit_user', format('name %s>%s xp %s>%s lvl %s>%s', o.username, p_username, o.xp, p_xp, o.level, p_level), 0, o.coins, o.coins, p_reason);
end $$;
create function public.admin_set_perm(p_user uuid, p_perm text, p_on boolean) returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.is_owner() then raise exception 'only the owner can change administrator permissions'; end if;
  if p_perm <> all (array['view_balances','give_coins','remove_coins','set_coins','bulk_give','give_cards','give_packs','give_items','edit_inventory','edit_users','edit_players','edit_packs','edit_economy','post_announcements','view_transactions','reverse_transactions']) then raise exception 'unknown permission'; end if;
  if exists (select 1 from auth.users u where u.id = p_user and lower(u.email) = 'adamsamyhal@gmail.com') then raise exception 'the owner already has every permission'; end if;
  if p_on then insert into public.admin_permissions(user_id, permission, granted_by) values (p_user, p_perm, auth.uid()) on conflict do nothing;
  else delete from public.admin_permissions where user_id = p_user and permission = p_perm; end if;
  perform public._audit('perm', jsonb_build_object('user', p_user, 'perm', p_perm, 'on', p_on));
end $$;
create function public.admin_set_setting(p_key text, p_value jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._need('edit_economy');
  if p_key !~ '^[a-z0-9_.]{2,60}$' then raise exception 'bad key'; end if;
  insert into public.settings(key, value, updated_by, updated_at) values (p_key, p_value, auth.uid(), now()) on conflict (key) do update set value = excluded.value, updated_by = auth.uid(), updated_at = now();
  perform public._audit('setting', jsonb_build_object('key', p_key, 'value', p_value));
end $$;
create function public.admin_upsert_pack(p jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._need('edit_packs');
  insert into public.packs(id, name, price, cards, pool_min, pool_max, er_min, er_max, color, descr, active, sort)
  values (p->>'id', p->>'name', (p->>'price')::int, (p->>'cards')::int, (p->>'pool_min')::int, (p->>'pool_max')::int, (p->>'er_min')::int, (p->>'er_max')::int, coalesce(p->>'color', '#8a949e'), coalesce(p->>'descr', ''), coalesce((p->>'active')::boolean, true), coalesce((p->>'sort')::int, 0))
  on conflict (id) do update set name = excluded.name, price = excluded.price, cards = excluded.cards, pool_min = excluded.pool_min, pool_max = excluded.pool_max, er_min = excluded.er_min, er_max = excluded.er_max, color = excluded.color, descr = excluded.descr, active = excluded.active, sort = excluded.sort;
  perform public._audit('pack', p);
end $$;
create function public.admin_upsert_player(p jsonb) returns text language plpgsql security definer set search_path = public as $$
declare k text := p->>'key';
begin
  perform public._need('edit_players');
  if k is null or k = '' then
    k := (p->>'name') || '|' || coalesce(nullif(p->>'club_code', ''), 'CUS') || '|' || coalesce(nullif(p->>'team', ''), 'CUS');
    insert into public.players(key, name, pos, rating, club_code, team, club, rarity, custom, active)
      values (k, p->>'name', p->>'pos', (p->>'rating')::int, coalesce(nullif(p->>'club_code', ''), 'CUS'), coalesce(nullif(p->>'team', ''), 'CUS'), p->>'club', nullif(p->>'rarity', ''), true, true);
  else
    update public.players set rating = (p->>'rating')::int, rarity = nullif(p->>'rarity', ''), active = coalesce((p->>'active')::boolean, active), pos = coalesce(p->>'pos', pos) where key = k;
    if not found then raise exception 'player not found'; end if;
  end if;
  perform public._audit('player', p); return k;
end $$;
create function public.admin_delete_player(p_key text) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._need('edit_players');
  delete from public.players where key = p_key and custom;
  if not found then raise exception 'only custom players can be deleted; disable built-in players instead'; end if;
  perform public._audit('player_delete', jsonb_build_object('key', p_key));
end $$;
create function public.admin_post_announcement(p jsonb) returns void language plpgsql security definer set search_path = public as $$
begin
  perform public._need('post_announcements');
  insert into public.announcements(title, body, kind, pinned, author) values (left(p->>'title', 120), left(p->>'body', 4000), coalesce(p->>'kind', 'update'), coalesce((p->>'pinned')::boolean, false), auth.uid());
end $$;
create function public.admin_delete_announcement(p_id bigint) returns void language plpgsql security definer set search_path = public as $$
begin perform public._need('post_announcements'); delete from public.announcements where id = p_id; end $$;

-- lock down: internal helpers are not callable from the browser; public functions only by signed-in users
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.is_owner(), public.has_perm(text) to anon, authenticated;
grant execute on function public.ensure_profile(), public.am_owner(), public.update_my_profile(text, text), public.claim_starter(), public.buy_pack(text),
  public.open_pack_item(uuid), public.claim_reward(text, text), public.report_match(text, int, boolean),
  public.admin_list_users(text), public.admin_get_user(uuid), public.admin_adjust_coins(uuid, text, bigint, text), public.admin_bulk_give(uuid[], bigint, text),
  public.admin_reverse_tx(bigint, text), public.admin_grant_item(uuid, text, text, int, int, jsonb, text), public.admin_remove_item(uuid, text),
  public.admin_update_user(uuid, text, text, bigint, int, text), public.admin_set_perm(uuid, text, boolean), public.admin_set_setting(text, jsonb),
  public.admin_upsert_pack(jsonb), public.admin_upsert_player(jsonb), public.admin_delete_player(text), public.admin_post_announcement(jsonb),
  public.admin_delete_announcement(bigint) to authenticated;
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;
